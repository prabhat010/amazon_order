class AmazonSearchResultsPage {
  constructor(page) { this.page = page; }

  async openFirstProduct() {
    await this.page.waitForSelector("h2 a.a-link-normal");
    await this.page.locator("h2 a.a-link-normal").first().click();
  }
}
module.exports = AmazonSearchResultsPage;
