class AmazonCartPage {
  constructor(page) { this.page = page; }

  async verifyCart() {
    await this.page.click("#nav-cart");
    await this.page.waitForSelector(".sc-list-item-content");
  }
}
module.exports = AmazonCartPage;
