class AmazonHomePage {
  constructor(page) { this.page = page; }

  async open() {
    await this.page.goto("https://www.amazon.in/");
    await this.page.waitForSelector("#twotabsearchtextbox");
  }

  async search(item) {
    await this.page.fill("#twotabsearchtextbox", item);
    await this.page.click("input[type='submit']");
  }
}
module.exports = AmazonHomePage;
