class AmazonProductPage {
  constructor(page) { this.page = page; }

  async addToCart() {
    await this.page.waitForSelector("#add-to-cart-button", { timeout: 20000 });
    await this.page.click("#add-to-cart-button");
  }
}
module.exports = AmazonProductPage;
