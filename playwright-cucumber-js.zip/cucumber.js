module.exports = {
  default: {
    require: ["./steps/*.js"],
    paths: ["./features/*.feature"],
    format: ["progress"],
    publishQuiet: true
  }
};
