module.exports = {
  use: { headless: false }
};
