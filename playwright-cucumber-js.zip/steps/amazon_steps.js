const { Given, When, Then } = require("@cucumber/cucumber");
const { chromium } = require("playwright");

const AmazonHomePage = require("../pages/AmazonHomePage");
const AmazonSearchResultsPage = require("../pages/AmazonSearchResultsPage");
const AmazonProductPage = require("../pages/AmazonProductPage");
const AmazonCartPage = require("../pages/AmazonCartPage");

let browser, page;
let home, results, product, cart;

Given("I open Amazon", async function () {
  browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  page = await context.newPage();

  home = new AmazonHomePage(page);
  results = new AmazonSearchResultsPage(page);
  product = new AmazonProductPage(page);
  cart = new AmazonCartPage(page);

  await home.open();
});

When("I search for {string}", async function (item) {
  await home.search(item);
});

When("I open the first product", async function () {
  await results.openFirstProduct();
});

When("I add it to cart", async function () {
  await product.addToCart();
});

Then("I should see the product in cart", async function () {
  await cart.verifyCart();
  await browser.close();
});
